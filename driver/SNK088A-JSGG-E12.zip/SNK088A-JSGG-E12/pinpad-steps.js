
/*
 * { 
 * 		// 输入密码操作
 * 		action: 'input',
 * 		timeout: function() // 超时处理函数
 * 		cardNo: string, // 卡号
 * 		keyPress: function(name, value), // optional 按键处理函数
 * 		success: function(self, data), // optional
 * 		error: function(self, data) // optional
 * }
 * 
 * {
 * 		// 更新密钥操作
 * 		action: 'update',
 * 		key: string, // 密钥
 * 		success: function(self, data), // optional
 * 		error: function(self, data) // optional
 * }
 * 		
 */
/** 密码键盘 */
Module(
		'Eurus',
		function(m) {
			Class(
					'PinPadStep',
					{
						isa : Eurus.DeviceStep,
						override : {
							validate : function() {
								if (!this.context.action)
									throw new Eurus.Exception("action 未设置");
								if (!this.context.cardNo)
									throw new Eurus.Exception("cardNo 未设置");
								if (this.context.action == 'input'
										&& typeof this.context.timeout != 'function')
									throw new Eurus.Exception("timeout 未设置");
								if (this.context.action == 'update'
										&& !this.context.key)
									throw new Eurus.Exception("key 未设置");
							},
							inject : function() {
								var self = this;
								var injectedError = function(data) {
									self.context.errorFunc(self, data);
									self.context.done(self, false);
								};
								if (typeof this.context.error != 'function'
										&& typeof this.context.errorFunc != 'function') {
									this.context.error = injectedError;
									this.context.errorFunc = function(data) {
										log.error("Error:" + data.status);
									};
								}
								if (typeof this.context.error == 'function'
										&& typeof this.context.errorFunc != 'function') {
									this.context.errorFunc = this.context.error;
									this.context.error = injectedError;
								}

								var injectedSuccess = function(data) {
									self.context.successFunc(self, data);
									self.context.done(this);
								};
								
								if (typeof this.context.success != 'function'
										&& typeof this.context.successFunc != 'function') {
									this.context.success = injectedSuccess;
									this.context.successFunc = function(data) {
										log.debug('status: ' + data.status);
										if (data.status == 'completed')
											self.output.pinBlock = data.pinBlock;
									};
								}
								if (typeof this.context.success == 'function'
										&& typeof this.context.successFunc != 'function') {
									this.context.successFunc = this.context.success;
									this.context.success = injectedSuccess;
								}
							}
						},
						methods : {
							invoke : function() {
								try {
									var self = this;
									if (this.context.action == 'input') {
										var ret = GGPinPad.open();
										if (ret == 0) {
											PinpadKeyPressEvent = function(
													name, value) {
												var key = "";
												switch (name) {
												case "*":
													key = "+";
													break;
												case "BackSpace":
													// 回退
													key = "clear";
													break;
												case "Clear":
													// 回退
													key = "clear";
													break;
												case "Enter":
													// 确定，绑定了confirm按键
													key = "confirm";
													break;
												case "ESC":
													// 确定，绑定了cancel按键
													key = "cancel";
													break;
												default:
													break;
												}
												if (key == 'cancel'){
													// 清空所有事件监听
													GGPinPad.cancel();
													GGPinPad.clearClose();
													if (typeof self.context.cancel == 'function')
														self.context.cancel();

														self.context.success(self, {
															status : 'cancelled'
														});
												}else{													
													if (typeof self.context.keyPress == 'function') {
														self.context.keyPress(key);
													} else {
														zzt.flex.changeInput(key);
													}
												}
											};

											// 按键成功
											PinpadEntryCompleteEvent = function() {
												// 确定
												var pinBlock = GGPinPad
														.getPinBlock(self.context.cardNo);
												GGPinPad.clearClose();
												if (typeof self.context.success == 'function'){
													self.context.success(self,{
														status : 'completed',
														pinBlock : pinBlock
													});
												}
												else{
													zzt.flex
															.changeInput("confirm");
													}
											};

											// 按键超时时间
											PinpadEntryTimeoutEvent = function() {
												// 清楚所有的清空事件
												// 调用超时方法
												GGPinPad.clearClose();
												if (typeof self.context.timeout == 'function')
													self.context.error({
														status : 'timeout'
													});
											};

											GGPinPad.startInput({
												timeout : self.context.timeout,
												success : function() {
												},
												error : function() {
													log.error("错误：无法使用密码键盘");
													self.context.error({
														status : 'cant_use'
													});
												}
											});
										} else {
											log.error('错误：无法打开密码键盘');
											self.context.error({
												status : 'cant_open'
											});
										}
									}

									if (this.context.action == 'update') {
										var openRet=GGPinPad.open();
//										alert("打开密码键盘："+openRet);
										if(openRet==0){
										var ret = GGPinPad
												.updateKey(self.context.key);
//										alert("更新密钥0为成功："+ret);
										if (ret == 0){
//											alert("success");
											GGPinPad.close();
											var jsonObj={"status":"success"};
											self.context.success(self,jsonObj);}
										else{
//											alert("失败");
											GGPinPad.close();
											var jsonObj={"status":"fail"};
											self.context.error(self,jsonObj);}}
										else{
											log.error("密码键盘无法打开");
										}
									}
								} catch (e) {
									log.error("密码键盘读取错误：" + JSON.stringify(e));
								}
							}
						}
					});
		});
