/**
 * 凭条打印机代理
 * 
 * @author hanz
 */
Module('Eurus', function(m) {
	Class('ReceiptStep', {
		isa : Eurus.DeviceStep,
		override : {
			validate : function() {
				if (!this.context.action)
					throw new Eurus.Exception("action 未设置");
			},
			inject : function() {
				var self = this;
				var injectedSuccess = function(data) {
					if (typeof self.context.successFunc == 'function')
						self.context.successFunc(self, data);
					self.context.done(self);
				};
				var injectedError = function(data) {
					if (typeof self.context.errorFunc == 'function')
						self.context.errorFunc(self, data);
					self.context.done(self, false);
				};
				if (typeof this.context.success != 'function') {
					// no success func input
					this.context.successFunc = function(self, data) {
					};
					this.context.success = injectedSuccess;
				} else {
					if (typeof this.context.successFunc != 'function') {
						this.context.successFunc = this.context.success;
						this.context.success = injectedSuccess;
					} else {
					}
				}
				
				if (typeof this.context.error != 'function') {
					// no error func input
					this.context.errorFunc = function(self, data) {
					};
					this.context.error = injectedError;
				} else {
					if (typeof this.context.errorFunc != 'function') {
						this.context.errorFunc = this.context.error;
						this.context.error = injectedError;
					} else {
					}
				}
			}
		},
		methods : {
			invoke : function() {
				try {
					var self = this;
					var info = {
						success : function(data) {
							self.context.success(self, data);
						},
						error : function(data) {
							self.context.error(self, data);
						}
					};
					if (this.context.action == 'open')
						GGReceiptPrinter.open(info);
					if (this.context.action == 'close') {
						var ret = GGReceiptPrinter.close();
						if (ret == 0)
							info.success();
						else
							info.error();
					}
					if (this.context.action == 'print') {
						if (!this.context.lines) {
							throw new Eurus.Exception("lines未设置");
						}else{
							// FIXME: please remove afterwards
							this.context.lines = '    '+ this.context.lines.replace('|', '|    ');
							this.context.lines = '    '+ this.context.lines.replace('\n','\n    ');
//							alert(this.context.lines.replace('|','\n'));
						}
						var items = this.context.lines.split('[/b]');
						var ret = 0;
						for (i in items) {
							var tokens = items[i].split('[b]');
							ret += GGReceiptPrinter.canceldouble();
							ret += GGReceiptPrinter.printData({
								lines : tokens[0],
								success : function() {
								},
								error : function() {
								}
							});
							if (tokens.length = 2) {
								ret += GGReceiptPrinter.double();
								ret += GGReceiptPrinter.printData({
									lines : tokens[1],
									success : function() {
									},
									error : function() {
									}
								});
							}
						}
						ret += GGReceiptPrinter.cut();
//						alert('ret = '+ret);
						
						// 存储凭条
						zzt.ajax({
							params : {
								REQ_HEAD : {
									TradeType : "STORE_RECEIPT"
								},
								REQ_BODY:{
									content :  encodeURI(this.context.lines),
									flowNo : allin.transactionNo,
									medCardType : allin.medCardType,
									medCardNo : allin.medCardNo
								}
							},
							success:function(data){
								log.info("ajax-->凭条数据记录成功");
							},
							error:function(data){
								log.error("ajax-->凭条数据记录执行错误");
							}
						});
						
						if (ret == 0)
							info.success();
						else
							info.error();
					}
				} catch (e) {
					log.error("凭条打印机错误：" + JSON.stringify(e));
				}
			}
		}
	});
});
