var _ReceiptPrinter = function() 
{
    var ReceiptPrinter = new _Ocx({
        classid : 'CLSID:197E7217-693B-4437-BCC0-29210CAE4EE5',
        id : 'ReceiptPrinterId',
        desc : '打印机'
    });

    //打开
    this.open = function(info) {
        var ret = ReceiptPrinter.ocx().OpenDevice();
        if (ret == 0) { //成功打开
        	var printerStatus=GGReceiptPrinter.getStatus();
        	if(printerStatus.statusCode==0){
            info.success();}
        	else{
        		info.error();
        	}
        } else {
            info.error();
        }
		return ret;
    };

    //关闭
    this.close = function() {
        return ReceiptPrinter.ocx().CloseDevice();
    };

    var statusMap = new Map();
    statusMap.put(0, '打印机正常并有纸');
    statusMap.put(1, '打印机正常，纸将尽');
    statusMap.put(2, '打印机正常，无纸');
    statusMap.put(3, '打印机故障');

    //获取状态
    this.getStatus = function(info) {
        var status = ReceiptPrinter.ocx().DeviceStatus;
        return {
            //错误码
            statusCode : status,
            //错误信息
            statusMsg : (statusMap.get(status) == null) ? '未知错误' : statusMap
            .get(status)
        };
    };

    /*
		打印数据
		@info
		- lines : 打印内容
		- success : 成功调用的方法
		- error ：失败调用方法
	 */
    this.printData = function(info) {
        var ret = ReceiptPrinter.ocx().PrintStr(info.lines);
        if (ret == 0) { //成功打印
            info.success();
        } else {
            info.error();
        }
		return ret;
    };
	
    this.printcode128 = function(info){
        var ret = ReceiptPrinter.ocx().printcode128(220,info.lines,100,3);
        if (ret == 0) { //成功打印
        	info.success();
        } else {
        	info.error();
        }
		return ret;
    };

    //变大
    this.double = function() {
        ReceiptPrinter.ocx().SetPrintFont("DoubleHeight|DoubleWidth");
		return 0;
    };
	
    //还原
    this.canceldouble = function() {
        ReceiptPrinter.ocx().SetPrintFont("");
		return 0;
    };

    //切纸刷卡
    this.cut = function() {
        ReceiptPrinter.ocx().Cut();
        ReceiptPrinter.ocx().Clear();
		return 0;
    };
};

var GGReceiptPrinter = new _ReceiptPrinter();
//页面卸载的时候关闭
addUnload(function()
{	//关闭打印机
	GGReceiptPrinter.close();
});

//以下是测试调用
////////////////////////////////////////////////////////////
/*
ReceiptPrinter.open({
	//是否打开串口
	success : function() {
		var statusInfo = ReceiptPrinter.getStatus();
		if (statusInfo.statusCode == 0) { //可进行正常打印
			ReceiptPrinter.printData({
				lines : '11|22|33|',
				success : function() {
					//打印成功后切纸
					ReceiptPrinter.cut();
					//关闭串口
					ReceiptPrinter.close();
					//页面调转
					//....
				},
				error : function() {
					alert('打印机打印错误');
				}
			})
		} else {
			alert('打印机错误：' + statusInfo.statusMsg);
		}
	},
	error : function() {
		alert('打印机打开错误');
	}
});
*/
