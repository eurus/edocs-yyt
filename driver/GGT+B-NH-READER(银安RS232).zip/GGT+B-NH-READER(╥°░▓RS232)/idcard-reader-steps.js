/**
 * 身份证读卡器代理
 * 
 * @author hanz
 */

Module('Eurus', function(m) {
	Class('IDCardStep', {
		isa : Eurus.DeviceStep,
		override : {
			validate : function() {
				if (!this.context.action)
					throw new Eurus.Exception("action 未设置");
			}
		},
		methods : {
			invoke : function(context) {
				try {
					var self = this;
					if (this.context.action == 'read') {
						var ret = GGIdCardReader.open({
							success : function() {
							},
							error : function() {
							}
						});
						if (ret == 0) {// 成功打开
							IDCardOn = function() {
								var output = {
									name : GGIdCardReader.readName(),
									idCode : GGIdCardReader.readIdCode(),
									sex : GGIdCardReader.readSex(),
									birthday : GGIdCardReader.readBirthday(),
									address : GGIdCardReader.readAddress()
								};

								self.output = output;
								if (output.name == '') {
									self.error = "读取信息失败：二代证";
									self.context.done(self, false);
								}
								log.info('idcard read: ' + JSON.stringify(output));
								ret = GGIdCardReader.close();
								if (ret != 0) {
									self.error = "关闭硬件失败：二代证";
									self.context.done(self, false);
								} else {
									self.context.success(self, output);
									self.context.done(self);
								}
							};
						} else {
							self.error = "打开硬件失败：二代证";
							self.context.done(self, false);
						}
					}
				} catch (e) {
					log.error("身份证读卡器错误：" + JSON.stringify(e));
				}
			}
		}
	});
});
