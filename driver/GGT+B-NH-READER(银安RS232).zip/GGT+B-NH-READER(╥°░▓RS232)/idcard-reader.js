/**
 * 身份证读卡器事件
 * @author victor
 */

var IDCardOn = function(){};
var IDCardTake = function(){};

var _IdCardReader = function() {
	var IdCardReader = new _Ocx({
		classid : 'CLSID:A84304A7-959F-41CF-BF48-866865BF68F0',
		id : 'IdCard',
		desc : '身份证读卡器'
	});
	
	// 加入检测事件
	IdCardReader.addEvent("IDCardOn", "IDCardOn()");
	IdCardReader.addEvent("IDCardTake", "IDCardTake()");

	/**
	 * 打开
	 */
	this.open = function(info) {
		var ret = IdCardReader.ocx().OpenDevice();
		if (ret == 0) { // 成功打开
			info.success();
		} else {
			info.error();
		}
		return ret;
	};
	
	this.readName = function() {
		var name = IdCardReader.ocx().Name;
		return name;
	};
	
	this.readIdCode = function() {
		return IdCardReader.ocx().IDCode;
	};
	
	this.readSex = function() {
		return IdCardReader.ocx().Sex;
	};
	
	this.readBirthday = function() {
		return IdCardReader.ocx().Birthday;
	};
	
	this.readAddress = function() {
		return IdCardReader.ocx().Address;
	};
	
	/**
	 *  关闭
	 */
	this.close = function() {
		return IdCardReader.ocx().CloseDevice();
	};
};
// 密码键盘对象
var GGIdCardReader = new _IdCardReader();
