var CardReaderInsertEvent = function() {
};
var CardReaderTakeEvent = function() {
};
/**
 * 磁卡机驱动
 * @return
 */
var _CardReader = function() {
		var CardReader = new _Ocx({
			classid : 'CLSID:6E6C8A44-A794-4845-9403-4D1D99E20869',
			id : 'CardReader',
			desc : '磁卡机'
		});	
	// 加入检测事件
	CardReader.addEvent("OnInsertCard", "CardReaderInsertEvent()");
	CardReader.addEvent("OnCardTaken", "CardReaderTakeEvent()");
	// 打开
	this.open = function() {
		return CardReader.ocx().OpenDevice();

	};
	// 关闭
	this.close = function() {
		return CardReader.ocx().CloseDevice();
	};

	// 初始化
	this.init = function() { /* 0 退卡 1 吞卡 2保留 */
		return CardReader.ocx().Init(0);
	};

	// 进卡
	this.insertCard = function(info) {
		/* cardtype 0：磁卡 1：IC卡 */
		return CardReader.ocx().EnableInsert(0, info.timeout);
	};

	// 禁卡
	this.disabledInsert = function() {
		return CardReader.ocx().DisableInsert();
	};

	// 退卡
	this.eject = function() {
		return CardReader.ocx().EjectCard(30);
	};

	// 回收卡片
	this.retain = function() {
		return CardReader.ocx().RetainCard();
	};

	// 读取2磁道数据
	this.readTrack2 = function() {
		var trackData = '';
		var ret = CardReader.ocx().ReadTrack(2);
		trackData = CardReader.ocx().Track2;
		return trackData;
	};
	// 读取3磁道数据
	this.readTrack3 = function() {
		var trackData = '';
		var ret = CardReader.ocx().ReadTrack(3);
		trackData = CardReader.ocx().Track3;
		return trackData;
	};

	// 获取磁卡机状态/* 0 正常 1未连接 2 故障 */
	this.getDevStatus = function() { 
		return CardReader.ocx().getStatus();
//		return CardReader.ocx().DevStatus;
	};

	// 获取卡片状态
	this.getCardStatus = function() { /* 0无卡1卡在门口2卡在读卡器里面 */
		return CardReader.ocx().getStatus();
//		return CardReader.ocx().CardStatus;
	};

	// 卡放入事件
	this.isCardInsert = function() {
		CardReaderInsertEvent = function(){
			
		};
	};

	// 取消卡放入
	this.cancelCardInsert = function() {
		CardReaderInsertEvent = function() {
		};
	};

	// 卡取走事件
	this.isCardTaken = function() {
		CardReaderTakeEvent = function(){
		};
	};

	// 取消卡放入
	this.cancelCardTaken = function() {
		CardReaderTakeEvent = function() {
		};
	};
};

// 磁卡机
var GGCardReader = new _CardReader();
// 页面卸载的时候关闭
/*
addUnload(function() {
	GGCardReader.close();
});
_CardReader.prototype.initial = function(info) {
	GGCardReader.init({
		success : function() {
			info.success();
		},
		error : function() {
			info.error();
		}
	});
};
// 重写磁卡机禁卡命令
_CardReader.prototype.disableEntry = function() {
	GGCardReader.disabledInsert();
	GGCardReader.eject();
};
// 重写磁卡机进卡命令
_CardReader.prototype.doCardEntry = function(info) { // 查询卡状态
	var status = GGCardReader.getCardStatus();
	// 插卡超时
	var insertTimeout = 0;
	if (status == 1 || status == 2) { // 1:比如卡在门口，卡在中间 2:比如卡在门口，吞卡
		GGCardReader.retain();
		// 2秒以后再做插卡，不然磁卡机来不及接受命令
		insertTimeout = 1;
	}

	// 线程重新发进卡命令
	new Thread(function() {
		GGCardReader.insert({
			timeout : info.timeout,
			success : function() {
				// alert("success");
				GGCardReader.isCardInsert(function() {
					// 取消进卡事件
					// alert("进卡");
					GGCardReader.cancelCardInsert();
					// 读取2磁道数据
					var trackData = GGCardReader.readTrack();
					//
					var trackData3 = GGCardReader.readTrack3();
					info.success(trackData, trackData3);
				});
			},
			error : function(msg) {
				GGCardReader.init({
					success : function() {
						info.error(msg);
					},
					error : function() {
						info.error(msg);
					}
				});
			}
		});
	}).start(insertTimeout);
};
*/