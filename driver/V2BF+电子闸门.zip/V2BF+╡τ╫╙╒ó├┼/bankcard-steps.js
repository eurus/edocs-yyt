Module(
		'Eurus',
		function(m) {
			Class(
					'BankCardStep',
					{
						isa : Eurus.DeviceStep,
						override : {
							validate : function() {
								if (!this.context.action)
									throw new Eurus.Exception("action 未设置");
							}
						},
						methods : {
							invoke : function() {
								var self = this;
								try {
									if (this.context.action == 'readCard') {
										var ret = GGCardReader.open();
										if (ret == 0 /*&& initCode == 0*/) {
												var input = {
													timeout : 2000
												};
											ret=GGCardReader.insertCard(input);
											CardReaderInsertEvent = function() {
													var track2 = GGCardReader
															.readTrack2();
													var track3 = GGCardReader
															.readTrack3();
													if (track2.indexOf("=") > 0) {
														var cardNo = track2
																.substring(
																		0,
																		track2
																				.indexOf("="));
														self.output.bankCardNo = cardNo;
														self.output.track2 = track2;
														self.output.track3 = track3;
														self.context.success(
																self,
																self.output);
														self.context.done(self);
													} else {
														self.error = "银行卡读卡异常";
														self.context.error(
																self, false);
													}
												//}
												//setTimeout(readTrack(), 500);
											};
											
//											if (insertCode == 0) {
//
//											} else {
//												self.error = "银行卡插卡失败";
//												self.context.error(self);
//											}

										} else {
											self.error = "打开硬件失败：openDevice";
											self.context.done(self, false);
										}
									}

								} catch (e) {
									log.debug("" + JSON.stringify(e));
									log.error("银行卡读卡错误：" + JSON.stringify(e));
								}

								try {

									if (this.context.action == 'eject') {
										var ret = GGCardReader.eject();
										if (ret == 0) {// 成功退卡
											// self.context.done(self);
											ret = GGCardReader.close();
											if (ret != 0) {
												self.error = "关闭硬件失败： 银行卡读卡器";
												self.context.done(self, false);
											} else {
												log.info("退卡成功");
												self.output.returnCode = ret;
												self.context.success(self,
														self.output);
												self.context.done(self);
											}

										} else {// 退卡不成功，执行吞卡操作
											ret = GGCardReader.retain();
											if (ret == 0) { // 吞卡成功
												ret = GGCardReader.close();
												if (ret != 0) {
													self.error = "退卡失败，已吞卡；关闭硬件失败： 银行卡读卡器";
													self.context.done(self,
															false);
												} else {
													log.info("退卡失败");
													self.output.returnCode = ret;
													self.context.success(self,
															self.output);
													self.context.done(self);
												}
											} else { // 吞卡失败
												ret = GGCardReader.close();
												if (ret != 0) {
													self.error = "退卡失败，未吞卡；关闭硬件失败： 银行卡读卡器";
													self.context.done(self,
															false);
												} else {
													self.context.error = "退卡失败，未吞卡";
													self.context.done(self,
															false);
												}
											}
										}
									}

								} catch (e) {
									log.info("eject = " + JSON.stringify(e));
								}
							}

						}
					});
		});
