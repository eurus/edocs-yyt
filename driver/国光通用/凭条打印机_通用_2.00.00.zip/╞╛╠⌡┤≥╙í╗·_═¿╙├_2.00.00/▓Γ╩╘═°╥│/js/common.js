function mainChange(_url)
{
	document.getElementById('index_main').src = _url;
}

/*树初始化*/
function initTree(json)
{
	var _json = json;
	var tree = document.getElementById('treeId');
	for(var i=0;i<_json.length;i++)
	{
		var ul = document.createElement('ul');
		var li = document.createElement('li');	
		li.className = (_json[i].opened==true)?'Opened':'Closed';
		
		var ahref = document.createElement('a');
		ahref.href = '#';
		ahref.innerHTML = _json[i].name;
		li.appendChild(ahref);
		
		if(_json[i].child.length>0)
		{
			var ulChild = document.createElement('ul');
			for(var j=0;j<_json[i].child.length;j++)
			{
				var liChild = document.createElement('li');	
				liChild.className = 'Child';
				
				var ahrefChild = document.createElement('a');
				
				ahrefChild.onclick = 'mainChange("'+_json[i].child[j].value+'")';
				ahrefChild.href = '#';
				ahrefChild.innerHTML = _json[i].child[j].name;
				
				liChild.appendChild(ahrefChild);
				ulChild.appendChild(liChild);
			}
			li.appendChild(ulChild);
			ul.appendChild(li);
			tree.appendChild(ul);
		}
	}
}

//菜单初始化
function initMenu(menuJson,doc)
{
	var _menuJson = menuJson;
	var bar = doc.getElementById('barId');
	if(bar==null)
		return;
		
	var menu = doc.createElement('ul');
	menu.id = 'menu';	
	menu.className = 'menu';
	
	for(var i=0;i<menuJson.length;i++)
	{
		var li = doc.createElement('li');
		var a = doc.createElement('a');	
		a.href = '#';
		a.innerHTML = menuJson[i].name;
		//无混动显示
		if(menuJson[i].type=='button')
		{
			li.className = 'nodiv';
			a.onclick = menuJson[i].fn;
		}
		li.appendChild(a);
		
		if(menuJson[i].type=='info')
		{	//是否是信息提示
			var childUl =  doc.createElement('ul');
			childUl.id = 'info';
			var childLi = doc.createElement('li');
			var childa = doc.createElement('a');	
			childa.innerHTML = menuJson[i].text;
			childLi.appendChild(childa);
			childUl.appendChild(childLi);
			li.appendChild(childUl);
		}
		else if(menuJson[i].type=='menu')
		{
			if(_menuJson[i].child!=null&&_menuJson[i].child.length>0)
			{
				var childUl =  doc.createElement('ul');
				for(var j=0;j<menuJson[i].child.length;j++)
				{
					var node = 	menuJson[i].child[j];
					var childLi = doc.createElement('li');
					var childa = doc.createElement('a');	
					childa.href = '#';
					
					childa.innerHTML = node.name;
					childa.onclick = node.fn;
					childLi.appendChild(childa);
					childUl.appendChild(childLi);
				}
				li.appendChild(childUl);
			}
		}
		menu.appendChild(li);
	}
	
	bar.appendChild(menu);
	return bar.innerHTML;
}

//记录日志
function log(msg)
{
	var console = document.getElementById('consoleInfo');
	console.value += new Date().format("MM/dd hh:mm:ss") +' - '+msg+'\r\n';
	//滚动到底部
	console.scrollTop = console.scrollHeight; 
}

//信息提示 
function msg(info)
{
	var msg = document.getElementById('showInfo');
	msg.innerHTML = info;
}

//清空日志
function clearLog()
{
	var console = document.getElementById('consoleInfo');
	console.value	= '';
}

Date.prototype.format = function(format) //author: meizz 
{ 
  var o = { 
    "M+" : this.getMonth()+1, //month 
    "d+" : this.getDate(),    //day 
    "h+" : this.getHours(),   //hour 
    "m+" : this.getMinutes(), //minute 
    "s+" : this.getSeconds(), //second 
    "q+" : Math.floor((this.getMonth()+3)/3),  //quarter 
    "S" : this.getMilliseconds() //millisecond 
  } 
  if(/(y+)/.test(format)) format=format.replace(RegExp.$1, 
    (this.getFullYear()+"").substr(4 - RegExp.$1.length)); 
  for(var k in o)if(new RegExp("("+ k +")").test(format)) 
    format = format.replace(RegExp.$1, 
      RegExp.$1.length==1 ? o[k] : 
        ("00"+ o[k]).substr((""+ o[k]).length)); 
  return format; 
};
