/**
 * @file 
 * 本脚本为<font color="blue">凭条</font>的扩展方法，提供基础方法的应用封装。<br>
 */
/**
 * @external _ReceiptPrinter
 */
//数据打印
var miniPrintInfo = null;
/**
 * 凭条打印机	打印数据
 * @function external:_ReceiptPrinter#printStr
 * @param info 			{Object} 	打印参数
 * @param info.data		{String}	打印数据
 * @param info.success	{Function}	打印成功
 * @param info.error	{Function}	打印失败
 * @description 
 * 数据格式以String为主
 * @example
 *	var value = "安徽农信凭测试|------------|客户姓名：张三|身份证号：3333333333|身份证号：3333333333|身份证号：3333333333|身份证号：3333333333|身份证号：3333333333|发卡：操作成功|时间：2014/10/28";
 *	var printStr = '';
 *	for(var i  in value)
 *		printStr += value[i]+'|';
 *	parent.log('打印数据为：'+printStr);
 *	GGReceiptPrinter.printStr({
 *		data : printStr,
 *		success : function(){
 *			parent.log('打印成功');
 *		},
 *		error : function(errorInfo){
 *			parent.log('打印失败，'+errorInfo);
 *		}
 *	});
 */
_ReceiptPrinter.prototype.printStr= function(info){
	//打印数据
	miniPrintInfo = info;
	//获取状态
	GGReceiptPrinter.getStatus();
	/**
	 * 设备状态<br>
	 * "0" --- 设备正常<br>
	 * "1" --- 设备忙<br>
	 * "2" --- 报警<br>
	 * "3" --- 故障<br>
	 */
	if(GGReceiptPrinter.DeviceStatus!="0")
	{	
		info.error('打印机异常，无法打印：'+GGReceiptPrinter.DeviceStatus);
		return;
	}
	
	//获取纸张状态
	GGReceiptPrinter.getPaperStatus();
	/**
	 * 纸张状态<br>
	 * "0" --- 有纸<br>
	 * "1" --- 纸将近<br>
	 * "2" --- 无纸<br>
	 */
	if(GGReceiptPrinter.PaperStatus=="2")
	{	
		info.error('打印机缺纸，无法打印！');
		return;
	}
	
	var printData = miniPrintInfo.data;
	var i;
	var t = new Array();
	t = printData.split("|");
  for (i = 0; i < t.length; i++) {
        GGReceiptPrinter.printString(t[i],"",1);	
  }
  println('打印完成，准备切纸...');
  GGReceiptPrinter.feedLines(5);
  GGReceiptPrinter.cut();
	miniPrintInfo.success();
	
}

/**
 * 凭条打印机	打印数据带字体风格
 * @function external:_ReceiptPrinter#printStr
 * @param info 			{Object} 	打印参数
 * @param info.data		{String}	打印数据（ △小字体#☆大字体#◇条码数据#|）,
 * @param info.barleft 			{String} 	条码左边距
 * @param info.barheight 			{String} 	条码高度
 * @param info.barwidth 			{String} 	条码宽度
 * @param info.success	{Function}	打印成功
 * @param info.error	{Function}	打印失败
 * @description 
 * 数据格式以String为主
 * @example
 *	var value = "安徽农信凭测试|------------|客户姓名：张三|身份证号：3333333333|身份证号：3333333333|身份证号：3333333333|身份证号：3333333333|身份证号：3333333333|发卡：操作成功|时间：2014/10/28";
 *	var printStr = '';
 *	for(var i  in value)
 *		printStr += value[i]+'|';
 *	parent.log('打印数据为：'+printStr);
 *	GGReceiptPrinter.printStr({
 *		data : printStr,
 *		success : function(){
 *			parent.log('打印成功');
 *		},
 *		error : function(errorInfo){
 *			parent.log('打印失败，'+errorInfo);
 *		}
 *	});
 */
_ReceiptPrinter.prototype.printStrByStyle= function(info){
	//打印数据
	miniPrintInfo = info;
	//获取状态
	GGReceiptPrinter.getStatus();
	/**
	 * 设备状态<br>
	 * "0" --- 设备正常<br>
	 * "1" --- 设备忙<br>
	 * "2" --- 报警<br>
	 * "3" --- 故障<br>
	 */
	if(GGReceiptPrinter.DeviceStatus!="0")
	{	
		info.error('打印机异常，无法打印：'+GGReceiptPrinter.DeviceStatus);
		return;
	}
	
	//获取纸张状态
	GGReceiptPrinter.getPaperStatus();
	/**
	 * 纸张状态<br>
	 * "0" --- 有纸<br>
	 * "1" --- 纸将近<br>
	 * "2" --- 无纸<br>
	 */
	if(GGReceiptPrinter.PaperStatus=="2")
	{	
		info.error('打印机缺纸，无法打印！');
		return;
	}
	
	var printData = miniPrintInfo.data;
	var i,j;
	var barleft=10;
	var barheight=40;
	var barwidth=2;
  var t = new Array();
  var v = new Array();
  t = printData.split("|");
  for (i = 0; i < t.length; i++) {
      v = t[i].split("#");
      for (j = 0; j < v.length; j++) {
           if (v[j].length > 0) {
               if (v[j].substring(0, 1) == "☆") {
                       GGReceiptPrinter.printString(v[j].substring(1),'Boldface|DoubleHeight|DoubleWidth',0);
               }
               else if ( v[j].substring(0, 1) == "◇" ){
               	      if(miniPrintInfo.barleft) barleft = miniPrintInfo.barleft;
               	      if(miniPrintInfo.barheight) barheight = miniPrintInfo.barheight;
               	      if(miniPrintInfo.barwidth) barwidth = miniPrintInfo.barwidth;
               				GGReceiptPrinter.printBarCode('',barleft,barheight,barwidth,v[j].substring(1));
               }
               else {
                       GGReceiptPrinter.printString(v[j].substring(1),'',0);
               }
           }
       }
     GGReceiptPrinter.feedLines(1);
  }	
  println('打印完成，准备切纸...');
  GGReceiptPrinter.feedLines(5);
  GGReceiptPrinter.cut();
	miniPrintInfo.success();
}