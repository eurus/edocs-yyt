/**
 * @fileOverview 凭条脚本API
 * @since 2015年4月
 */ 
var _receiptPrinter = null;
var _receiptInfo = null;

/** 
 * 凭条打印API
 * @class 
 * @param {Ojbect} info 			参数配置
 * @param {String} info.initAuto 	是否自动加载,true：自动加载，false：懒加载 - 需调用init方法加载
 * @since 2014.10.31
 */
var _ReceiptPrinter = function(info){
	var isInit = false;
	//加载驱动
	var ReceiptPrinter = null;
	/**
	 * 设备状态<br>
	 * "0" --- 设备正常<br>
	 * "1" --- 设备忙<br>
	 * "2" --- 报警<br>
	 * "3" --- 故障<br>
	 */
	this.DeviceStatus = '';

	/**
	 * 纸张状态<br>
	 * "0" --- 有纸<br>
	 * "1" --- 纸将近<br>
	 * "2" --- 无纸<br>
	 */
	this.PaperStatus = '';
	
	
	/**
	*设定凭条打印机类型
	*/
	this.setDeviceType = function(info){
		println(' -- ReceiptPrinter setDeviceType--');
	  if(ReceiptPrinter == null)
			return;
		_receiptInfo = info;
		ReceiptPrinter.ocx().SetDeviceType(_receiptInfo.type);
	}
	
	
	/**
	 * 打开设备
	 * @function
	 * @param	{Object}	info			入参
	 * @param	{Function}	info.success	成功调用方法
	 * @param	{Function}	info.error		失败调用方法
	 */
	 this.open = function(info){
		println(' -- ReceiptPrinter open..');
	  if(ReceiptPrinter == null)
			return;
		_receiptInfo = info;
		
    var ret = ReceiptPrinter.ocx().OpenDevice();
    if (ret == 0) {
    	  println("设备打开成功");
        if (_receiptInfo.success != null)
            _receiptInfo.success(ret);
    } 
    else {
    	  println("设备打开失败");
        if (_receiptInfo.error != null)
            _receiptInfo.error(ret);
    }
    return ret;
	};
	
	/**
	 * 关闭设备
	 */
	this.close = function(info){
		println(' -- ReceiptPrinter close..');
		if(ReceiptPrinter == null)
			return;
		ReceiptPrinter.ocx().CloseDevice();
	};
	
	/**
	 * 获取设备状态<br>
	 * 更新状态有：DeviceStatus，PaperStatus
	 */
	this.getStatus = function()
	{	
		println(' -- ReceiptPrinter getStatus..');
		if(ReceiptPrinter == null)
			return;
		
		this.DeviceStatus = ReceiptPrinter.ocx().GetDeviceStatus();
		println("DeviceStatus：" + this.DeviceStatus);
	};
	
	/**
	 * 获取纸张状态<br>
	 * 需先调用getStatus
	 */
	this.getPaperStatus = function()
	{
		println(' -- ReceiptPrinter getPaperStatus..');
		if(ReceiptPrinter == null)
			return;
		
		this.DeviceStatus = ReceiptPrinter.ocx().GetDeviceStatus();
		this.PaperStatus = ReceiptPrinter.ocx().GetPaperStatus();
		println("PaperStatus" + this.PaperStatus);
	};
	
	/**
	*设定行距 单位0.1mm取值范围30-254
	*/
	this.setRowDistance = function(rowdistance){
		println(' -- ReceiptPrinter setRowDistance --');
	  if(ReceiptPrinter == null)
			return;
		return ReceiptPrinter.ocx().SetRowDistance(rowdistance);
	}
	
	/**
	*设定左边距 单位0.1mm取值范围30-254
	*/
	this.setLeftMargin = function(leftmargin){
		println(' -- ReceiptPrinter setLeftMargin --');
	  if(ReceiptPrinter == null)
			return;
		return ReceiptPrinter.ocx().SetLeftMargin(leftmargin);
	}
	
		/**
	 * 打印数据
	 * @param	{String}	str		打印数据 
	 */
	this.print = function(str)
	{
		println(' -- ReceiptPrinter print..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().PrintString(str,'',1);
	};
	
	
	/**
	 * 打印数据
	 * @param	{String}	str		打印数据 
	 * @param	{String}	style		字体风格 Boldface、DoubleHeight、DoubleWidth、CharacterB、UnderLine
	 * @param	{int}		autoenter	是否自动换行
	 */
	this.printString = function(str,style,autoenter)
	{
		println(' -- ReceiptPrinter printString..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().PrintString(str,style,autoenter);
	};
	
	/**
	 * 打印条码
	 * @param	{String}	style		字体风格
	 * @param	{int}		left	左边距
	 * @param	{int}		height	条码高度
	 * @param	{int}		width	条码宽度
	 * @param	{String}	str		打印数据
	 */
	this.printBarCode = function(style,left,height,width,str)
	{
		println(' -- ReceiptPrinter printBarCode..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().PrintBarCode(style,left,height,width,str)
	};
	
	/**
	 * 走纸行
	 * @param	{int}		line	行数
	 */
	this.feedLines = function(line)
	{
		println(' -- ReceiptPrinter feedLines..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().FeedLines(line);
	};
	
	/**
	 * 走纸
	 * @param	{int}	distance	走纸距离，0.1mm为单位
	 */
	this.feed = function(distance)
	{
		println(' -- ReceiptPrinter feed..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().Feed(distance);
	};
	
	/**
	 * 切纸
	 */
	this.cut = function()
	{
		println(' -- ReceiptPrinter cut..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().CutPaper();
	}
	
	/**
	 * 设置重置
	 */
	this.reset = function()
	{	
		println(' -- ReceiptPrinter reset..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().InitDevice();
	};
	
	/**
	 * 定位到黑标
	 */
	this.blackMarkIdentify = function()
	{	
		println(' -- ReceiptPrinter blackMarkIdentify..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().BlackMarkIdentify();
	};
	
	/**
	 * 设置切纸距离 pt30111系列(爱普生指令集)打印机不支持此方法
	 */
	this.setCutOffset  = function(Distance)
	{	
		println(' -- ReceiptPrinter setCutOffset..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().SetCutOffset(Distance);
	};
	
	/**
	 * 设置打印起始距离 pt30111系列(爱普生指令集)打印机不支持此方法
	 */
	this.setStartPrintOffset = function(Distance)
	{	
		println(' -- ReceiptPrinter setStartPrintOffset..');
		if(ReceiptPrinter == null)
			return;
		
		return ReceiptPrinter.ocx().SetStartPrintOffset(Distance);
	};
	
	
	/**
	 * 懒加载方法
	 * @description 
	 * 如果定义没有加载就调用此方法，做驱动的加载
	 */
	this.init = function()
	{
		if(!isInit)
		{	//加载成功
			isInit = true;
			//开始加载空间
			ReceiptPrinter = new _Ocx({
				classid : 'CLSID:56CCA3B3-ED76-428A-B52A-F690CEFB32AA',
				id : 'ReceiptPrinterId',
				container : 'printOcx',
				width : 10,
				height : 10,
				desc : '凭条驱动'
			});
		}
	};
	
	/**
	 * ocx调用
	 * @return {_Ocx} 调用实例
	 */
	this.ocx = function(){
		if(ReceiptPrinter!=null)
			return ReceiptPrinter.ocx();
		
		return null;
	};
	
	//是否自动加载
	if(info.initAuto && !isInit)
	{	
		this.init();
	}
};

/**
 * @var {_ReceiptPrinter} GGReceiptPrinter	凭条打印类
 * @description 框架自动加载，查找到是否有JConfig对象，来进行加载
 */
var GGReceiptPrinter = new _ReceiptPrinter({
	//自动加载
	initAuto : JConfig.deviceAutoInit
});

	