/*******************************************************************************
 * JavaScript Code for CNLTreeMenu Version: Ver 1.02 Author : CNLei, 枫岩 E-Mail :
 * CNLei.Y.L@gmail.com MySite : http://www.cnlei.net Passed : XHtml 1.0, CSS
 * 2.0, IE5.0+, FF1.0+, Opera8.5+ Update : 2006-2-12
 ******************************************************************************/
function Ob(o) {
	var o = document.getElementById(o) ? document.getElementById(o) : o;
	return o;
}
function Hd(o) {
	Ob(o).style.display = "none";
}
function Sw(o) {
	Ob(o).style.display = "";
}
function ExCls(o, a, b, n) {
	if(isString(o))
		o = document.getElementById(o);
	
	var o = Ob(o);
	for (i = 0; i < n; i++) {
		o = o.parentNode;
	}
	o.className = o.className == a ? b : a;
}
function isString(o)
{ 
	return (typeof o=='string')&&o.constructor==String; 
};

function CNLTreeMenu(id, TagName0) {
	this.id = id;
	this.TagName0 = TagName0 == "" ? "li" : TagName0;
	this.AllNodes = Ob(this.id).getElementsByTagName(TagName0);
	this.InitCss = function(ClassName0, ClassName1, ClassName2, ImgUrl) {
		this.ClassName0 = ClassName0;
		this.ClassName1 = ClassName1;
		this.ClassName2 = ClassName2;
		this.ImgUrl = ImgUrl || "css/s.gif";
		for (i = 0; i < this.AllNodes.length; i++) {
			this.ImgBlankA = "<img id='s"+i+"' src=\"" + this.ImgUrl
					+ "\" class=\"s\" onclick=\"ExCls(this,'" + ClassName0
					+ "','" + ClassName1 + "',1);\" alt=\"展开/折叠\" />";
			this.ImgBlankB = "<img src=\"" + this.ImgUrl + "\" class=\"s\" />";
			this.AllNodes[i].className == "" ? this.AllNodes[i].className = ClassName1: "";
			if(this.AllNodes[i].innerHTML.indexOf("UL")>0)
			{
				this.AllNodes[i].innerHTML = this.AllNodes[i].innerHTML.substring(0, 2) + 
							" onclick=\"ExCls('s"+i+"','" + ClassName0
							+ "','" + ClassName1 + "',1);\" " + 
							"style=\"font-family:'simhei';font-size:15px;color:'windowframe';\" " + 
							"onmouseover = \"this.style.color = 'tomato';this.style.fontSize = '18px';\"; "+
							"onmouseout = \"this.style.color = 'windowframe';this.style.fontSize = '15px';\" "+
							this.AllNodes[i].innerHTML.substring(2, this.AllNodes[i].innerHTML.length);
			}
				
			if (this.AllNodes[i].className != ClassName2)
				this.AllNodes[i].innerHTML = this.ImgBlankA + " ☞ " + this.AllNodes[i].innerHTML;
			else
				this.AllNodes[i].innerHTML = this.ImgBlankB + this.AllNodes[i].innerHTML;
		}
	}
	this.SetNodes = function(n) {
		var sClsName = n == 0 ? this.ClassName0 : this.ClassName1;
		for (i = 0; i < this.AllNodes.length; i++) {
			this.AllNodes[i].className == this.ClassName2 ? "" : this.AllNodes[i].className = sClsName;
		}
	}
}
