//是否自动重启
var JConfig = {
	deviceAutoInit : false
};
/**
 * _Ocx类
 */
var _Ocx = function(info)
{	
	var clsid = info.classid;
	var id = info.id ;
	var init = false;
	var desc = info.desc;
	var divId = info.container?info.container:"ocx";
	if(id==null||clsid==null)
	{
		alert(desc+'的ocx的id或clsid为空，请设置');
		return;
	}
	var _ocx = null;
	if(info.objectId!=null)
	{	//是否已经具备
		_ocx = document.getElementById(info.objectId);
	}
	else
	{	
		try
		{	//没有具备id
			_ocx = document.createElement("object");
			_ocx.name = id;
			_ocx.id = id;
			_ocx.width = info.width==null?3:info.width;
			_ocx.height =  info.height==null?3:info.height;
			_ocx.classid = clsid;
			_ocx.style.zIndex = -1;
			if(info.codebase)
				_ocx.codeBase = info.codebase;
			appendElement('ocx', _ocx);
			init = true;
		}
		catch(e)
		{
			alert('ocx(id:'+id+')clsid:'+clsid+' 加载失败，'+e.description);
		}
	}
	
	this.addEvent = function(name, fnText)
	{	//创造事件
		var ocxEvent = document.createElement("SCRIPT");
		ocxEvent.htmlFor = id;
		ocxEvent.event= name;
		ocxEvent.language = "JavaScript";
		ocxEvent.className = "_EventClass";
		ocxEvent.text  =  formatFnText(fnText);
		appendElement('event', ocxEvent);
	};
	
	this.resetEvent = function(name, fnText)
	{	//重新定义事件
		$('._EventClass').each(function(){
			if($(this).attr('event') == name)
			{
				this.text = formatFnText(fnText);
				return;
			}
		});
	};
	
	this.addEventList = function(list)
	{	
		for(var i in list)
		{	//创造事件
			var ocxEvent = document.createElement("SCRIPT");
			ocxEvent.htmlFor = id;
			ocxEvent.event= list[i].name;
			ocxEvent.language = "JavaScript";
			ocxEvent.className = "_EventClass";
			ocxEvent.text  =  formatFnText(list[i].fn);
			appendElement('event', ocxEvent);
		}
	};
	
	this.removeEvent = function(name){
		if(name==null)
			$('._EventClass').remove();
		else
			$('._EventClass').each(function(){
				if($(this).attr('event')==name)
					$(this).remove();
			});
	}
	
	function appendElement(name, el)
	{
		var ocxDiv = document.getElementById(divId);
		if(ocxDiv!=null && name!='event')
			ocxDiv.appendChild(el);
		else
			document.body.appendChild(el);
	};
	
	function formatFnText(fnText)
	{
		if(jQuery.isFunction(fnText))
		{
			fnText = fnText.toString();
			fnText = fnText.substring(fnText.indexOf("{")+1,fnText.length-1);
		}
		return fnText;
	}
	
	this.isInit = function()
	{
		return init;
	};
	
	this.ocx = function()
	{
		return _ocx;
	};
};

/**
 * 显示对话框
 * @param info 			{Object} 	入参
 * @param info.labels 	{Array} 	内容
 * @param info.btnName 	{String=} 	按钮名称，默认递交
 * @param info.info 	{String=} 	提示
 * @param info.click	{Function}	返回 输入框内容,多个输入框以"|"做分割
 * @param info.close	{Function=}	关闭触发函数，有则执行
 */
function showInput(info)
{	//先做清除
	$('#InputBox').remove();
	var html = '<div id="InputBox" class="inputDivClass">' ;
	for(var i=0; i<info.labels.length; i++)
	{
		html += '<span align="center">'+info.labels[i]+'</span><br>';
		html += '<input id="InputBox_input'+i+'" type="text" size="35">';
		html += (i!=info.labels.length-1)?'<br>':'&nbsp;&nbsp;&nbsp;';
	}
	html += '<input type="button" id="InputBox_btn" value="'+(info.btnName?info.btnName:' 递交 ')+'"/>';		
	html += '&nbsp;&nbsp;&nbsp;'
	html += '<input type="button" id="InputBox_close_btn" value=" 关闭 "/>';	
	html += info.info?'<br><br><font style="color:grey;" size=3>' +info.info+ '</font>':'';
	html += '</div>';
	//加入html
	$('body').append(html);
	$('#InputBox').css('display','block');
	//重新定义click
	$('#InputBox_btn').click(function(){
		var retValue = '';
		for(var i=0; i<info.labels.length; i++)
		{
			retValue += $('#InputBox_input'+i).val()+'|';
		}
		parent.log("输入返回：" + retValue);
		//清空
		$('#InputBox').remove();
		//回调
		if(info.click)
			info.click(retValue.split('|'));
	});
	//关闭
	$('#InputBox_close_btn').click(function(){
		if(info.close)
			info.close();
		closeInput();
	});
}

/**
 * 显示对话框
 * @param info 			{Object} 	入参
 * @param info.title 	{String=} 	标题
 * @param info.labels 	{Array} 	内容
 * @param info.btnName 	{String=} 	按钮名称，默认递交
 * @param info.info 	{String=} 	提示
 * @param info.click	{Function}	返回 输入框内容
 * @param info.close	{Function=}	关闭触发函数，有则执行
 */
function showSelectInput(info)
{	//先做清除
	$('#InputBox').remove();
	var html = '<div id="InputBox" class="inputDivClass">' ;
	if(info.title)
		html += '<span>'+info.title+'</span><br><br>';
	html += '<h2>'
	for(var i=0; i<info.labels.length; i++)
		html += '<INPUT type=radio value="'+i+'" name="InputBox_radio" '+ ((i==0)?'CHECKED>':'>') + 
				info.labels[i] + 
				'&nbsp;&nbsp;';
	html += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	html += '<input type="button" id="InputBox_btn" value="'+(info.btnName?info.btnName:' 递交 ')+'">';		
	html += '&nbsp;&nbsp;&nbsp;'
	html += '<input type="button" id="InputBox_close_btn" value=" 关闭 " alt="close">';		
	html += '</h2>';
	html += info.info?'<br><br><font style="color:grey;" size=3>' +info.info+ '</font>':'';
	html += '</div>';
	//加入html
	$('body').append(html);
	$('#InputBox').css('display','block');
	//重新定义click
	$('#InputBox_btn').click(function(){
		var retValue = $('input:radio:checked').val();
		parent.log("输入返回：" + retValue);
		//清空
		$('#InputBox').remove();
		//回调
		if(info.click)
			info.click(retValue);
	});
	//关闭
	$('#InputBox_close_btn').click(function(){
		if(info.close)
			info.close();
		closeInput();
	});
}



/**
 * 关闭输入窗口
 */
function closeInput()
{
	$('#InputBox').remove();
}

/**
 * 加载设备信息
 * @param {Object} devices
 * @param {String} 	devices.name 			设备加载名称
 * @param {String=} devices.container	 	设备加载容器
 * @param {String=} devices.append	 		加载内容
 */
function loadDeviceInfo(devices)
{
	var html = '<BR><h2>&nbsp;&nbsp;驱动加载信息  <font color="grey" size=2> Driver Info</font>';
	html += '&nbsp;&nbsp;&nbsp;&nbsp;';
	html += '<table align="right" widht=150><tr><td>';
	html += '{&nbsp;';
	html += devices.name;
	html += '&nbsp;&nbsp;&nbsp;';
	html += '<span id="'+(devices.container?devices.container:'ocx') +'" style="width:50px;">';
	html += devices.append?devices.append:'';
	html += '</span>';
	html += '&nbsp;}&nbsp;';
	html += '</td></tr></table></h2><BR><hr><BR>';
	$('.nav').after(html);
}

/**
 * 通用组件
 */
var GGUtils = function(){
	var ggUtilOcx = new _Ocx({
		classid : 'clsid:BB6D2616-9224-4A91-B6F2-03F0655C56B6',
		id : 'gGutilsId',
		width : '5',
		height : '5',
		desc : '通用控件'
	});
	
	this.readIni = function(json){
		var ocx = ggUtilOcx.ocx();
		if(ocx!=null)
			return ocx.zztReadIni(json.iniFile,json.section,json.key,json.defval);
		else
			return json.defval;
	};
	
	this.writeIni = function(json){
		var ocx = ggUtilOcx.ocx();
		if(ocx!=null)
			return ocx.zztWriteIni(json.iniFile,json.section,json.key,json.val);
		return -9;
	};
};

//打印日志
function println(msg)
{
	if(parent && parent.log)
		parent.log(msg);
}