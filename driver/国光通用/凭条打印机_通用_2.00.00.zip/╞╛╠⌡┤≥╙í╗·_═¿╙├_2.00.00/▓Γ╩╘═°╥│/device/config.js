/*
	树列表
 */
var treeJson = [ {
	name : '热敏打印机',
	opened : false,
	child : [ {
		name : '凭条打印机',
		value : 'device/1_微打/receiptprinter.htm'
	} ]
} ]