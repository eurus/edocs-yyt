// 事件处理函数
var PinpadKeyPressEvent = function(name, value) {
};
var PinpadEntryCompleteEvent = function() {
};
var PinpadEntryCancelledEvent = function() {
};
var PinpadEntryTimeoutEvent = function() {
};

/**
 * 密码键盘
 */
var _Pinpad = function() {
	var Pinpad = new _Ocx({
		classid : 'CLSID:82FA40B5-ABE6-4C0C-9BD2-20636BF9E921',
		id : 'PinpadId',
		desc : '密码键盘'
	});

	// 加入检测事件
	// PKeyName：按键名称，“0” ...
	// “9”、“Enter”、“Esc”、“Clear”、“Backspace”、“DECPOINT”,”*”，
	// PKeyValue：按键值，对应以上按键的值分别为16进制的30...39、0D、1B、2A、08、2E。
	// 按输入什么值来判断下一步动作
	// 如果是数字就Flex增加×
	// 如果clear就Flex清空输入框
	// 如果BackSpace Flex删除一个*
	// 如果enter,密码键盘输入达到最小位数的情况，就产生完成事件，得到加密值，没达到Flex咋提示，还是没动作
	// DECPOINT的话Flex不增加*,密码没小数点 ，×号键同样处理
	// Esc的就会产生取消事件,调用CancelEntry

	Pinpad.addEvent("KeyPress(PKeyName,PKeyValue)",
			"PinpadKeyPressEvent(PKeyName,PKeyValue)");
	Pinpad.addEvent("EntryComplete", "PinpadEntryCompleteEvent()");
	Pinpad.addEvent("EntryCancelled", "PinpadEntryCancelledEvent()");
	Pinpad.addEvent("EntryTimeout", "PinpadEntryTimeoutEvent()");

	// 打开
	this.open = function() {
		if(allin.issueDeviceStatus=='yes'){
			return Pinpad.ocx().OpenDevice("COM9",1);
		}else
			return Pinpad.ocx().OpenDevice("COM2", 1);
	};

	// 关闭
	this.close = function() {
		return Pinpad.ocx().CloseDevice();
	};

	// 更新第三方工作密钥，签到时候调用
	this.updateKey = function(key) {
		// var ret = Pinpad.ocx().PosUpdateParameteSelect(info.key,2);
		return Pinpad.ocx().PosUpdateParamete(key);
	};

	// 获取第三方主密钥
	this.getMasterKey = function() {
		return Pinpad.ocx().GetUnEntryMasterkey();
	};

	// 获取第三方工作密钥
	this.getMacKey = function() {
		return Pinpad.ocx().GetUnEntryMackey();
	};

	// 开始输入密码之前，需要调用此方法设置输入模式
	this.startInput = function(info) {
		// 密码有效最短，最长，是否要按确认得到结果，超时时间
		return Pinpad.ocx().PinEntry(4, 6, false, info.timeout);
	};

	// 取消输入状态，PinpadEntryCancelledEvent事件后，必须执行，输入密码超时，也必须执行
	this.cancel = function() {
		return Pinpad.ocx().CancelEntry();
	};

	// 读键盘密文信息,需要EntryComplete产生后才能读取
	this.getPinBlock = function(cardNo) {
		return Pinpad.ocx().GenPosRequestMsg('99', cardNo);
	};

	// 以下是事件
	// ===============================================================
	// 按键事件
	// 取消按键事件
	this.cancelKeyPressEvent = function() {
		PinpadKeyPressEvent = function() {
		};
	};

	// 取消按键确认事件
	this.cancelKeyPressComplete = function() {
		PinpadEntryCompleteEvent = function() {
		};
	};

	// 取消按键取消事件
	this.cancelEntryCancelledEvent = function() {
		PinpadEntryCancelledEvent = function() {
		};
	};

	// 取消按键超时事件
	this.cancelEntryTimeoutEvent = function() {
		PinpadEntryTimeoutEvent = function() {
		};
	};

	// 取消所有事件
	this.clearClose = function() {
		GGPinPad.cancelKeyPressEvent();
		GGPinPad.cancelEntryCancelledEvent();
		GGPinPad.cancelEntryTimeoutEvent();
		GGPinPad.cancelEntryTimeoutEvent();
		GGPinPad.close();
	};
};

// 密码键盘
var GGPinPad = new _Pinpad();
