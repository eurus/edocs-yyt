var CodeReaderEvent = function(){};
/**
 * 条形码.js
 * @return
 */
var _BarCodeReader = function()
{
    var BarCodeReader = new _Ocx({
        classid : 'CLSID:4A02A62F-24DB-46CD-9EE3-53935B484375',
        id : 'BarCodeReader',
        desc : '条形码'
    });
    
    //加入刷条码事件
    BarCodeReader.addEvent("SwipeSuccess","CodeReaderEvent()");
	
    //打开条码扫描
    this.open = function(info)
    {	//设置端口
        //BarCodeReader.ocx().port=5;
        
    	var ret = BarCodeReader.ocx().OpenDevice();
        if(ret==0)
        {	//成功打开
        	if(info.success!=null)
        		info.success();
        }
        else
        {
        	if(info.error!=null)
        		info.error();
        }
    };
	//关闭
    this.close = function()
    {
    	BarCodeReader.ocx().CloseDevice();
    };

    this.getBarCode = function()
    {	
    	return BarCodeReader.ocx().BarCode;
    };
   
    this.isWaitSwipe = function(fn){
    	CodeReaderEvent= fn;
    };
    
    this.cancelWaitSwipe = function(fn){
    	CodeReaderEvent= function(){};
    };
    
    //等待刷条码
	this.swipe = function(info)
	{
		var ret = BarCodeReader.ocx().WaitSwipe();
		if(ret==0)
		{	//成功打开
			info.success();
		}
		else
		{
			info.error();
		}
	};
	this.BarCodeMsg = function()
	{
		return BarCodeReader.ocx().BarCode;
	};
	//扫描成功事件
	this.isCodeSuss = function(fn)
	{
		CodeReaderEvent = fn;
	};
    
//

};
var GGBarCodeReader = new _BarCodeReader();
