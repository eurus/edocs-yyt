//条码枪
var BarCodeSussEvent = function(){};
var BarCodeFailEvent = function(){};

var _BarCode = function()
{
	var BarCode = new _Ocx({
		classid : 'CLSID:D92C5983-F1D8-4623-A42F-8CC912755EC4',
		id : 'BarCode',
		desc : ''
	});
	
	//加入检测事件
	BarCode.addEvent("SwipeSuccess","BarCodeSussEvent()");
	BarCode.addEvent("SwipeFail", "BarCodeFailEvent()");
	
	//取消扫描
	this.cancel = function()
	{
		return BarCode.ocx().exit_scan();
	};
	
	//开始扫描
	this.swipe = function()
	{
		return BarCode.ocx().showBarCodeAnimation();
	};
	
	this.getBarCode = function()
	{
		return BarCode.ocx().getBarCode();
	};
};
//条码枪
var GGBarCode = new _BarCode();	
