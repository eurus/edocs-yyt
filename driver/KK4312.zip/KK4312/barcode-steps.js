/**
 * 条形码扫描枪代理
 * 
 * @author hanz
 */

Module('Eurus', function(m) {
	Class('BarCodeStep', {
		isa : Eurus.DeviceStep,
		override : {
			validate : function() {
				if (!this.context.action)
					throw new Eurus.Exception("action 未设置");
			}
		},
		methods : {
			invoke : function() {
				try {
					var self = this;
					if (this.context.action == 'read') {
						BarCodeSussEvent = function() {
							var barcode = GGBarCode.getBarCode();
							if (barcode != null && barcode != '') {
								self.output.barcode = barcode;
								self.context.success(self, self.output);
								self.context.done(self);
							} else {
								self.error = "读取信息失败：条形码";
								self.context.error(self);
								self.context.done(self, false);
							}
						};

						BarCodeFailEvent = function() {
							self.error = "读取信息超时：条形码";
							self.context.error(self);
							self.context.done(self,false);
						};
						GGBarCode.swipe();
					}
				} catch (e) {
					log.error("条形码读取错误：" + JSON.stringify(e));
				}
			}
		}
	});
});
