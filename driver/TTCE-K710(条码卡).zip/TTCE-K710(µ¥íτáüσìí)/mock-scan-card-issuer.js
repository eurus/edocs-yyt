/**
 * 发卡条码枪ocx控制器
 * 
 * @author simon
 * @constructor
 */
var _ScanCardIssuer = function() {

	/**
	 * 打开设备
	 */
	this.open = function() {
		return 0;
	};

	/**
	 * 关闭设备
	 */
	this.close = function() {
		return 0;
	};

	/**
	 * 移动卡
	 * 
	 * @param {String}
	 *            position 位置 0:卡口外,4:取卡位置,7:读卡位置
	 */
	this.moveCard = function(position) {
		return 0;
	};

	/**
	 * 读卡号
	 * @returns {returnCode: String, barcode: String}
	 */
	this.readCard = function() {
		return {
			returnCode: '0',
			barcode: '0000202'
		};
	};

	var cardStatusMap = new Map();
	cardStatusMap.put(0, '无卡');
	cardStatusMap.put(1, '卡在门口');
	cardStatusMap.put(2, '卡在读卡位');

	var stackStatusMap = new Map();
	stackStatusMap.put(0, '卡箱空');
	stackStatusMap.put(1, '卡箱将空');
	stackStatusMap.put(2, '卡箱满');

	/**
	 * 获取状态
	 * @returns {deviceStatus: int, cardStatus: int, stackStatus: int, cardStatusMsg: String, stackStatusMsg: String}
	 */
	this.getStatus = function() {
		return {
			deviceStatus : 0,
			cardStatus : 1,
			cardStatusMsg : '', 
			stackStatus : 1,
			stackStatusMsg : ''
		};
	};
	
	this.retainCard = function(){
		return 0;
	}
};

var GGScanCardIssuer = new _ScanCardIssuer();