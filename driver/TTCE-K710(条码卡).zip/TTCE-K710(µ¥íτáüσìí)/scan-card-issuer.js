/**
 * 发卡条码枪ocx控制器
 * 
 * @author simon
 * @constructor
 */
var _ScanCardIssuer = function() {
	var ScanCardIssuer = new _Ocx({
		classid : 'CLSID:394544CF-F1ED-4837-B535-0EB7FCA178CA',
		id : 'scanCardIssuerId',
		desc : '条码发卡机'
	});

	/**
	 * 打开设备
	 */
	this.open = function() {
		ScanCardIssuer.ocx().port = 8;
		return ScanCardIssuer.ocx().OpenDevice();
	};

	/**
	 * 关闭设备
	 */
	this.close = function() {
		return ScanCardIssuer.ocx().CloseDevice();
	};

	/**
	 * 移动卡
	 * 
	 * @param {String}
	 *            position 位置 0:卡口外,4:取卡位置,7:读卡位置
	 */
	this.moveCard = function(position) {
		return ScanCardIssuer.ocx().IssueCard(position);
	};

	/**
	 * 读卡号
	 * @returns {returnCode: String, barcode: String}
	 */
	this.readCard = function() {
		var data = ScanCardIssuer.ocx().ReadCard();
		var items = data.split("|");
		if (items[0] == '10')
			return {
				returnCode : '0',
				barcode : items[1]
			};
		else
			return {
				returnCode : items[0],
				barcode : ''
			};

	};

	var cardStatusMap = new Map();
	cardStatusMap.put(0, '无卡');
	cardStatusMap.put(1, '卡在门口');
	cardStatusMap.put(2, '卡在读卡位');

	var stackStatusMap = new Map();
	stackStatusMap.put(0, '卡箱空');
	stackStatusMap.put(1, '卡箱将空');
	stackStatusMap.put(2, '卡箱满');

	/**
	 * 获取状态
	 * @returns {deviceStatus: int, cardStatus: int, stackStatus: int, cardStatusMsg: String, stackStatusMsg: String}
	 */
	this.getStatus = function() {
		var cardStatus = ScanCardIssuer.ocx().CardState;
		var cardStatusMsg = cardStatusMap.get(cardStatus);
		var stackStatus = ScanCardIssuer.ocx().StackState;
		var stackStatusMsg = stackStatusMap.get(stackStatus);
		var deviceStatus = ScanCardIssuer.ocx().GetStatus();
		return {
			deviceStatus : deviceStatus,
			cardStatus : cardStatus,
			cardStatusMsg : (cardStatusMsg == null) ? '未知' : cardStatusMsg,
			stackStatus : stackStatus,
			stackStatusMsg : (stackStatusMsg == null) ? '未知' : stackStatusMsg
		};
	};
	
	this.retainCard = function(){
		return ScanCardIssuer.ocx().RetainCard();
	};
	this.reset = function(){
		return  ScanCardIssuer.ocx().Reset();
	};
};

var GGScanCardIssuer = new _ScanCardIssuer();