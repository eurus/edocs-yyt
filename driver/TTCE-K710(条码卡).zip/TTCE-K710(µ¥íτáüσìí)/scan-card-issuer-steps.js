/**
 * 条码发卡机代理
 * 
 * @author hanz
 */
Module('Eurus', function(m) {
	Class('ScanCardIssuerStep', {
		isa : Eurus.DeviceStep,
		override : {
			validate : function() {
				if (!this.context.action)
					throw new Eurus.Exception("action 未设置");
			},
			inject : function() {
				var self = this;
				var injectedSuccess = function(data) {
					self.output = data;
					if (typeof self.context.successFunc == 'function') {
						self.context.successFunc(self, data);
					}
					self.context.done(self);
				};
				var injectedError = function(data) {
					self.output = data;
					if (typeof self.context.errorFunc == 'function') {
						self.context.errorFunc(self, data);
					}
				};

				if (typeof this.context.success != 'function') {
					// no success func input
					this.context.successFunc = function(self, data) {
					};
					this.context.success = injectedSuccess;
				} else {
					if (typeof this.context.successFunc != 'function') {
						this.context.successFunc = this.context.success;
						this.context.success = injectedSuccess;
					} else {
					}
				}

				if (typeof this.context.error != 'function') {
					// no error func input
					this.context.errorFunc = function(self, data) {
					};
					this.context.error = injectedError;
				} else {
					if (typeof this.context.errorFunc != 'function') {
						this.context.errorFunc = this.context.error;
						this.context.error = injectedError;
					} else {
					}
				}
			}
		},
		methods : {
			invoke : function() {
				var self = this;
				try {
					var result = null;
					var ret = GGScanCardIssuer.open();
					if (ret == 0) {
						if (this.context.action == 'read') {
							ret = GGScanCardIssuer.moveCard(7);
							if (ret == 0) {
								sleep(800);
								result = GGScanCardIssuer.readCard();
								if (result.returnCode == 0) {
									result = {
										cardNo : result.barcode
									};
								} else {
									sleep(500);
									log.error("发卡机：无法读取卡片号，再读一遍");
									var readCode = GGScanCardIssuer.readCard();
									if(readCode.returnCode == 0){
										result = {
												cardNo : readCode.barcode
											};
									}else{
										sleep(500);
										var retainCode=GGScanCardIssuer.retainCard();
										if(retainCode==0){
											log.info("发卡机：吞卡成功(1)");
											result={
													cardNo:"",
													error:"发卡机：读卡失败，已经吞卡(1)"
											};
										}else{
											var rescode=GGScanCardIssuer.reset();
											log.debug("发卡机：复位");
											if(rescode==0){
												retainCode = GGScanCardIssuer.retainCard();
												if(retainCode==0){
													result={
															cardNo:"",
															error:"发卡机：读卡失败，已经吞卡(2)"
													};													
												}else{
													result={
															cardNo:"",
															error:"发卡机：读卡失败，吞卡失败(2)"
													};
												}
								
											}
												
										}										
									}								
								}
							} else {
								log.error("发卡机：读卡时无法移动卡片");
								result = {
									cardNo : '',
									error : '发卡机：无法移动卡片'
								};
							}
						}

						if (this.context.action == 'issue') {
							ret = GGScanCardIssuer.moveCard(4);
							if (ret == 0) {
								result = {};
							} else {
								result = {
									cardNo : '',
									error : '发卡机：无法移动卡片"'
								};
							}
						}
						if (this.context.action == 'retrieve') {
							ret = GGScanCardIssuer.retainCard();
							if (ret == 0) {
								var rescode=GGScanCardIssuer.reset();
								if (rescode==0)
									log.info("发卡机：吞卡操作，复位成功");
								result = {};
							} else {
								result = {
									cardNo : '',
									error : '发卡机：回收卡片时出现错误，请重新操作"'
								};
							}
						}
						
						if (this.context.action == 'getStatus') {
							result = GGScanCardIssuer.getStatus();
						}
					} else {
						log.error("发卡机：无法打开设备");
						result = {
							cardNo : '',
							error : '发卡机：无法打开设备"'
						};
					}

					GGScanCardIssuer.close();

					if (result == null) {
						self.context.error(null);
					} else {
						if (typeof result.error == 'undefined') {
							self.context.success(result);
						} else {
							self.context.error(result);
						}
					}
				} catch (e) {
					log.error('发卡机 执行错误：' + JSON.stringify(e));
				}
			}
		}
	});
});
var scanCardIssuer = {};

scanCardIssuer.read = new Eurus.ScanCardIssuerStep('读取发卡机卡号', {
	action: 'read',
	success: function(self, data){
		if (data.cardNo!=''){
			allin.cardNo = data.cardNo;
		}else{
			go.hint("读取就诊卡号失败，按确定键返回","go.welcome()","go.welcome()");
		}	
	},
	error: function(self, data){
		log.error(data.error);
		go.hint("抱歉，发卡器出现了些问题，按确定键重新办卡。\n若问题未能解决，请及时检查发卡箱 ","go.welcome()","go.welcome");	
	}
});

var scanCardExecute_PreviousStep = new Eurus.JsStep("读卡返回继续执行", {
	execute : function(self, context) {
		var g = self.pipeline.globals;
		g.index++;
		log.debug("返回上步骤执行 操作次数=" + g.index);
		self.context.jump(-1);
	}
});
// Clone demo
//var x = scanCardIssuer.read.clone();
//x.context.success = function(self, data){};

scanCardIssuer.issue = new Eurus.ScanCardIssuerStep('发卡', {
	action: 'issue',
	success: function(self, data){
	},
	error: function(self, data){
		go.hint(data.error,"go.welcome()","go.welcome()");
	}
});

scanCardIssuer.getStatus = new Eurus.ScanCardIssuerStep("获取发卡机状态",{
	action:"getStatus",
	success : function(self,data){
		var g=self.pipeline.globals;
		g.index=0;
		if(data.cardStatus<0||data.stackStatus<0){
			self.context.jump("读卡返回继续执行");
		}else{
//			if(data.cardStatus==2&&g.index>=0){
//				log.debug("读卡位有卡，需要被回收。");
//				self.context.jump("回收卡片");
//			}else{
				log.info("当前发卡机状态："+JSON.stringify(data)+",index="+g.index);
				if(data.stackStatus==0&&g.index>=0){
					log.info("卡箱无卡");
					go.hint("卡箱已经没有就诊卡了\n请联系医院服务人员","go.welcome()");
				}else if(data.stackStatus==1&&g.index>=0){
					log.debug("卡箱将空");
					self.context.jump("读取发卡机卡号");
				}else if(data.stackStatus==2&&g.index>=0){
					log.debug("卡箱卡满");
					self.context.jump("读取发卡机卡号");
				}else{
//					if(data.cardStatus=="2"&&g.index>=0){
//						log.debug("读卡位有卡，需要被回收。");
//						self.context.jump("回收卡片");
//					}else{						
						self.context.jump("读取发卡机卡号");
//					}
				}
//			}
		}
	},error:function(self,data){
		log.error(" get status-->error="+data.error);
	}
});

scanCardIssuer.retrieve = new Eurus.ScanCardIssuerStep('回收卡片', {
	action: 'retrieve',
	success: function(self, data){
	},
	error: function(self, data){
		go.hint(data.error,"go.welcome()","go.welcome()");
	}
});