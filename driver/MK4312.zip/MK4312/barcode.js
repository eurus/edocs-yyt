//多线条码枪
var BarCodeSussEvent = function(){};
var BarCodeFailEvent = function(){};
var BarCodeInfo = {};

var _BarCode = function()
{
	var BarCode = new _Ocx({
		classid : 'CLSID:D92C5983-F1D8-4623-A42F-8CC912755EC4',
		id : 'BarCode',
		desc : '条码枪'
	});
	
	//加入检测事件
	BarCode.addEvent("SwipeSuccess","BarCodeSussEvent()");
	BarCode.addEvent("SwipeFail","BarCodeFailEvent()");
	
	//打开
	this.open = function()
	{
		return BarCode.ocx().showBarCodeAnimation();
		//return BarCode.ocx().OpenDevice();
	};
	
	//关闭
	this.close = function()
	{
		return BarCode.ocx().exit_scan();
		//return BarCode.ocx().CloseDevice();
	};
	
	//等待刷条码
	this.swipe = function()
	{
		//return BarCode.ocx().WaitSwipe();
	};
	
	this.BarCodeMsg = function()
	{
		//return BarCode.ocx().BarCode;
		return BarCode.ocx().getBarCode();
	};

};
//条码枪
var GGBarCode = new _BarCode();	
