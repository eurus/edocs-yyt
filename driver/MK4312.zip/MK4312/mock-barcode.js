//条码枪
var BarCodeSussEvent = function(){};
var BarCodeInfo = {};


var _BarCode = function()
{
	//打开
	this.open = function()
	{
		return 0;
	};
	
	//关闭
	this.close = function()
	{
		return 0;
	};
	
	//等待刷条码
	this.swipe = function(info)
	{
		setTimeout("BarCodeSussEvent()", 3000);
		return 0;
	};
	
	this.BarCodeMsg = function()
	{
		return "ZLK000000001";
	};

};
//条码枪
var GGBarCode = new _BarCode();	
