/**
 * 条形码扫描枪代理
 * 
 * @author hanz
 */

Module('Eurus', function(m) {
	Class('BarCodeStep', {
		isa : Eurus.DeviceStep,
		override : {
			validate : function() {
				if (!this.context.action)
					throw new Eurus.Exception("action 未设置");
			}
		},
		methods : {
			invoke : function() {
				try {
					var self = this;
					var info = {
						success : function(data) {
							self.context.success(data);
						},
						error : function(data) {
							self.context.error(data);
						}
					};
					BarCodeInfo = info;
					if (this.context.action == 'read') {
						var ret = GGBarCode.open();
						if (ret == 0) {
							BarCodeSussEvent = function() {
								var barcode = GGBarCode.BarCodeMsg();
								if (barcode != null && barcode != '') {
									self.output.barcode=barcode;
									var ret = GGBarCode.close();
									if (ret == 0){
										self.context.success(self,self.output);
										self.context.done(self);
									}
									else {
										self.error = "关闭硬件失败：条形码";
										self.context.error();
										self.context.done(self, false);
									}
								} else {
									self.error = "读取信息失败：条形码";
									self.context.error(self);
									self.context.done(self, false);
								}
							};
							BarCodeFailEvent=function(){
								log.info("条码枪读卡失败");
								go.welcome();
							};

							GGBarCode.swipe();
						} else {
							self.error = "打开硬件失败：条形码";
							self.context.done(self, false);
						}
					}
				} catch (e) {
					log.error("条形码读取错误：" + JSON.stringify(e));
				}
			}
		}
	});
});
